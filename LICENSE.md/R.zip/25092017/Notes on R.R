## Environment is the memory of R
## Enter the scripts in R Script window
## Console: Scripting window notebook 

## Todays objectives
## 1) How to tame R
##  a) Basic Syntax in R
##  b) Basic Statements in R
## 2) Basic data structures in R
## 3) Basic control statements in R
## 4) Basic Functions in R

### Variables in R
### x <- 5
### x = 5
### 5 -> x
### Execute - Ctrl+Enter, Cltr+R, Click Run
x <- 5
y <- 35

## Variables in R can hold data of different datatypes
## Data Types
## Double
## Integer
## Character
## Logical

## use the function typeof()
typeof(y)

## Append "L" to that data
y <- 35L
typeof(y)

## Assign integger value of 56 to a
## and double values of 23 to b anc check of type of a and b

a <- 46L
b <- 23
typeof(a)
typeof(b)

## Assign a character value
## ""
name <- "Sidd"
name
typeof(name)

## Assign Logical
# True
t <- TRUE
typeof(t)

d <- FALSE
typeof(d)

j <- T
k <- F

typeof(k)


### Most Important property in R
x <- 24
## X is a data structure which holdes of 34
## Basic Data structure in R is called a vector
## All x are similar to the array concept
## X[1] <- 34

## When you assign multiple values in R
## use C() - Combine
m <- c(34,45)
m
m[1]
m[2]

## Check the length of m
## use the function called lenght()
length(m)


## A Small exercise: Assign KPMG, Deloitte, PwC and EY to a variable called BigFour

BigFour <- c("KPMG", "Deloitte", "PwC", "EY")
BigFour
typeof(BigFour)
length(BigFour)

### Order of Character> Number>logic

# Vector is one of the data structure
# Others are :
# List
# Data Frame
# Matrix


# A Vector at any given point of time can hold only one data type
# assume I would like to assign a series from 4 to 14 in a variable h
h <- 4:14
h

## seq() - sequence functio
## seq(start value, stope value, increment by)
j <- seq(4,14,1)
j

## 4 to 14 increment by 3
k <- seq(4,14,3)
k

j <- seq(80,40,-2)
j

## Generate a series from 20 to 40 increment by 2 assign to d
##Find lenght of d and type of d
##Assign the length d to y

d <- seq(20,40,2)
d
length(d)
typeof(d)
y <- length(d)
y

e <- as.integer(d)
typeof(e)


## vector operations in + , -, * and /

x <- 7
y <- 8
x * y
z = x * y
z
print(z)

## another property
x <- c(5,6)
y <- c(7,8)
z <- x+y
z

# Recycling of data
a <- c(4,7,9,13)
b <- c(3,5)
c <- a * b
c


## assign valuesd fom 35 to 65 to j
## assign valuesd fom 45 to 54 to k
## mutliply j and k and store it in i

j <- seq(35,65,1)
k <- seq(45,54,1)
i <- j*k
i
length(j)
length(k)
length(i)
typeof(i)
v <- as.integer(i)
typeof(v)

## i should be caracter
e <- as.character(i)
typeof(e)


## Relational operations in a vector
## <, > <=, >=, ==, !=

m <- 7
h <- 9
m > h
a <- m>h
typeof(a)
a

## assign F,T,T,F,T to h
## assign T,F,F, T to y then add h to y and store in d
## analyze d and check the values in d and lenght of d

h <- c(F,T,T,F,T)
y <- c(T,F,F,T)

d <- h + y
d
length(d)


## Small exercise
## 12, 4, 6, 13, 8 to r
## 9, 10, 5, 11, 8, 13 to u
## Check if r > u and stoe the result in l

r <- c(12, 4, 6, 13, 8)
u <-  c(9, 10, 5, 11, 8, 13)
l <- r>u
l

## not equal to !=
x <- 5
y <- 7
z <- x!= y
z

# picking the value
d <- c(3,5,6,7,9,10)
d
d[3]
d[1:3]
d[c(1,4)]
d[-1]
d[c(-1,-2)]



## Lists : data structure which holds mutliple data types
## lists()
## chars KPMG, EY
## Emp strentght in integter
##BigFour Logical

list1 <- list(c("KPMG", "EY"), c(10000,12000), c(T,T))
list1

list1[1]
typeof(list1[[1]])


list1[2]
typeof(list1[[2]])


list1[3]
typeof(list1[[3]])

## Class()
y <- 5
class(y)
class(list1)


## Create a list of employees
## Assign the list to empdb
## empname: Rahul, Kumar, Priya
## Empage numeric 34, 45, 28
## Empleft  T, F, F
## Check the datatype of individuals records in the list


list2 <- list(c("Rahul", "Kumar", "Priya"), c(34,45, 28), c(T,F, F))
list2


list2[1]
typeof(list2[[1]])


list2[2]
typeof(list2[[2]])


list2[3]
typeof(list2[[3]])

## names() function to name the records
names(list1) <- c("FirmName", "EmpStr", "InBigFour")
list1

list1$FirmName
list1$FirmName[1]


# Add names to the list
list3 <- list(c("Rahul", "Kumar", "Priya"), c(34,45, 28), c(T,F, F))
names(list3) <- c("Name", "Age", "Left")
list3

list3$Name
list3[[1]][1]

list3$Age
list3[[2]][1]


list3$Left
list3[[3]][1]


## Variables in Lists
list3$Location <- "India"
list3

## Deleting a variable
list3
list5 <- list3
list5$Location <- NULL
list5


## empdb, remove empage from that list
## and add a new record officelocation
## to which assign values 'mumbai, gurgain, hyd
list3
list6 <- list3
list6$Age <- NULL
list6
list6$officelocation <- c("Mumbai", "Gurugram", "Hyderabad")
list6


## Matrix it can hold only one data type
## can be created using matrix()
mat1 <- matrix(3:17,nrow = 3)
mat1

mat2 <- matrix(3:17,nrow = 3, byrow = T)
mat2

mat2 + mat1


## Create a matrix from 13:27 with number of rows  = 4
## assign it to y
## create a matrix from 4:11 with number of rows  = 4
## assign to m
## add m to y
## save m + y to g


y <- matrix(13:27,nrow = 4, byrow = T)
y

m <- matrix(4:11,nrow = 4, byrow = T)
m

## Dimension should be same
dim(y)
dim(m)

#g = m + y

mat1[2,3]

# access all elements in secodn row
mat1[2,]
#all elemets except 2nd row
mat1[-2,]

#all elemets except 2nd row and 3rd col
mat1[-2,-3]

# elements only in 2 and 4 col
mat1[,c(2,4)]

### data structures - data frame
### can hold multiple data types'
### created sing function data.frame(), we pass vectors
## Empdb dataframe
## empnames, age, Doj
empnames <- c("T", "R", "Y")
Age <- c(34, 45, 24)
Doj <- c("4/5/16", "5/7/2014", "7/7/2011")
empdb <- data.frame(empnames,Age,Doj)


##Exercise
stdname <- c("G", "K", "L")
Pmarks <- as.integer(c(45, 47, 48))
cmarks <- as.integer(c(45, 46, 49))

marksdb <- data.frame(stdname, Pmarks, cmarks)

#marksdb$TotalMarks = c(marksdb$Pmarks + marksdb$cmarks)
TotalMarks = c(marksdb$Pmarks + marksdb$cmarks)
marksdb


## Cbind(marksdb)
sdb <- cbind(marksdb,TotalMarks)
sdb
dim(sdb)
names(sdb)


## custom functions in R
## function() {}
## function(x1,x2,x3)
## {
## activityies/tasks
## }


## write a function to a square

sq <- function(x) {
 a <- x * x
 return(a)
}

sq(50)


fExercise <- function(x,y) {
 a <- x*x 
 b <- y*y
 c <- a+b
 return(c)
}

fExercise(10,20)

# list of variables
ls()

# working directory
getwd()


# in built dataset in R
newdata = iris
View(newdata)

#information about data
?iris
?cbind

# First Six rows of the dataset
head(newdata)

#first n rows
head(newdata,12)

# last 6 rows
tail(newdata)

# last 12 rows
tail(newdata,12)

# Summary of the data - Central Tendency and Dispersion
summary(newdata)

## Structure of the data
str(newdata)

## Can you split the iris data into columns 1:3 in df1 and cols 4:5 for df2

df1 <- data.frame(newdata[,1:3])
df2 <- data.frame(newdata[,4:5])
tail(df1)
tail(df2)

## Combine data
cbind(df1,df2)

##Extract data from 1:50, 51: 100, 101:150 in df4, df5 and df6 and use Rbind function to et back datasets::

df4 = newdata[1:50,]
df5 = newdata[51:100,]
df6 = newdata[101:150,]

df4
df5
df6

cdf6 = rbind(df4,df5,df6) 
cdf6

##Can extract data where sepal length is greater than 5
## Subset
df7 = subset(newdata,newdata$Sepal.Length>5)
df7
##Can extract data where sepal length is greater than 5 for virgenia

df8 = subset(df7,df7$Species=="virginica")
df8
length(df8$Sepal.Length)
nrow(df8)

## multiple condition

df9 = subset(newdata,newdata$Sepal.Length>5 & newdata$Species=="virginica")
nrow(df9)


## Sepal lenght > 4
## Sepal widht <3
## speciies  Versicolor
df10 = subset(newdata,newdata$Sepal.Length > 4 & newdata$Sepal.Width < 3 & newdata$Species=="versicolor")
nrow(df10)



## Sepal lenght > 4
## Sepal widht <3
## speciies  Versicolor
df11 = subset(newdata,newdata$Sepal.Length > 4 & newdata$Sepal.Width < 3 & newdata$Species!="versicolor")
nrow(df11)


## box plot of ata for sepal.length
boxplot(newdata$Sepal.Length)

boxplot(newdata)

str(newdata)

boxplot(newdata$Species,newdata$Sepal.Length)
newdata$Species <- as.character(newdata$Species)
boxplot(newdata$Species, newdata$Sepal.Length)

## Barplot
barplot(newdata$Sepal.Length)
pie(newdata$Sepal.Width)
hist(newdata$Petal.Length)

#EDA
mean(newdata$Sepal.Length)
median(newdata$Sepal.Length)

##Apply
newdata$Species <-NULL
apply(newdata,1,mean)
apply(newdata,2,sd)

## Box plot for categorial variables
boxplot(iris$Sepal.Length ~iris$Species)



##
newdata2 <- iris

str(newdata2)
newdata2$Sepal.Length <- as.integer(newdata2$Sepal.Length)
str(newdata2)

names(newdata2)

