d1<- read.csv(file.choose())
View(d1)
is.na(d1)

which(is.na(d1))
str(d1)


## code the categorial variables
## Factor()

d1$Treatment <- factor(d1$Treatment, levels = c("A","B"), labels = c(1,2))

str(d1)

## read a data file named restful
d2 <- read.csv(file.choose())
View(d2)
d3 <- d2
d3 <- na.omit(d3)
View(d3)

# inorder to sperate variables
# separate()
library(tidyr)
d3 = separate(d3, year_mo_day, c("Year", "Month", "Day"), sep = "-")
View(d3)
str(d3)



## Reverseof what you have done
## unite()
## unite(data, new varaible, existing variable, sep)

d4 <- d3
d4 <- unite(d4, YYYYMMDD, Year, Month, Day, sep = "/")
View(d4)



## 
x3 <- 4:34
y3 <- 34:64
z3 <- 24:54
df1 <- data.frame(x3,y3,z3)
View(df1)

## Entering some NA to df1
df1[4,1] <- NA
df1[17,2] <- NA
df1[23,3] <- NA

# mean of df1 for x
mean(df1$x3, na.rm = T)


## data imputation
## replace the missing values with the mean of column
which(is.na(df1$x3))
df2 <- df1
df2$x3 <- ifelse(is.na(df2$x3), mean(df1$x3, na.rm = T), df2$x3)

df2$y3 <- ifelse(is.na(df2$y3), mean(df1$y3, na.rm = T), df2$y3)

df2$z3 <- ifelse(is.na(df2$z3), mean(df1$z3, na.rm = T), df2$z3)

View(df2)



## data exploration
?mtcars
dc1 <- mtcars
View(dc1)

plot(x= dc1$wt, y = dc1$mpg)

## ggplot
## data sent used in diamonds

library(ggplot2)
data(diamonds)
?diamonds 
View(diamonds)

## Clarity of the diamonds
## FL - Flawless
## I3 - Included
## IF - Internally Flawless
## VVS1  Very very slightly inlcuded
## vvs2
## vs1
## S1

dim(diamonds)
str(diamonds)
head(diamonds,15)

## Price and carat of the diamond
## ggplot - grammer of graphics
## by Hadley Wickham

dd1 = diamonds
library(ggplot2)
ggplot(data = dd1, aes(x = carat, y = price))+geom_point()


## Give a filter on Carat. Remove Carat greator than 3
ggplot(data = dd1[dd1$carat<3,], aes(x = carat, y = price))+geom_point()

## Color based on Clarity
ggplot(data = dd1[dd1$carat<3,], aes(x = carat, y = price, color = clarity))+geom_point()

## Change the shape of data
ggplot(data = dd1[dd1$carat<3,], aes(x = carat, y = price, color = clarity))+geom_smooth()

## assigning it to variables
gvar <- ggplot(data = dd1[dd1$carat<3,], aes(x = carat, y = price, color = clarity))+geom_smooth()

## Facet the data, take the individual feature
gvar + facet_wrap(~clarity)

gvar + facet_wrap(~clarity, nrow = 2)


## use the mtcars data set
## Plot weight againts mpg color - Automatic/manual
data(mtcars)
datamtc <- mtcars
View(datamtc)

str(datamtc)

datamtc$cyl <- as.factor(datamtc$cyl)
ggplot(data = datamtc, aes(x = cyl, y = mpg, color = hp))+geom_line()
mtcvar <- ggplot(data = datamtc, aes(x = wt, y = mpg, color = cyl))+geom_line()
## Facet the data, take the individual feature
mtcvar + facet_wrap(~am)


