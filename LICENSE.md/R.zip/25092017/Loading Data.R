nhsdata <- read.csv(file.choose())
View(nhsdata)
head(nhsdata)
#na.omit()
nhsdata$wt <- NULL

head(nhsdata)
is.na(nhsdata)
which(is.na(nhsdata))

nhsnewdata <-na.omit(nhsdata)
nhsnewdata
View(nhsnewdata)

nhsFull <- read.csv(file.choose())
View(nhsFull)
str(nhsFull)

nhsFull$SEX <- as.factor(nhsFull$SEX)

summary(nhsFull)

nhsFull$X <- NULL

str(nhsFull)
summary(nhsFull)

## Clean data based on weight
boxplot(nhsFull$weight)
nhscleandata <- subset(nhsFull,  nhsFull$weight < 400)
nhscleandata

## Clean data based on Sleep
boxplot(nhsFull$SLEEP)
nhscleandata <- subset(nhsFull,  nhsFull$SLEEP < 20)
nhscleandata

## Clean data based on edu
boxplot(nhsFull$educ)
nhscleandata <- subset(nhsFull,  nhsFull$educ < 25)
nhscleandata

## Clean data based on height
boxplot(nhsFull$height)
nhscleandata <- subset(nhsFull,  nhsFull$height < 80)
nhscleandata

## Clean data based on Weight
boxplot(nhsFull$weight)
nhscleandata <- subset(nhsFull,  nhsFull$weight < 300)
nhscleandata

summary(nhscleandata)

## Write files to directory
write.csv(nhscleandata,"cleannhsdata.csv")


## Loops
## For loop
## for(variable "in" "range values") {execute this}

for ( i in 2:10) {
  s <- i^2 
  print(s)
}

install.packages("ggplot2")

for ( p in 5:12) 
{
  s1 <- p^3 
  print(s1)
}

library(ggplot2)

##ifelse

m1 <- 6
ifelse(m1>0,"pos","Neg")

## repeat()
rep(1:3, times=4)
rep(1:3, each=3)

w1 <- c(1,1,1,3,3,3,2, 5,5,5)
unique(w1)
sort(unique(w1))

## reversing the vector
rev(w1)
rev(sort(unique(w1)))
sort(unique(w1),decreasing=T)


