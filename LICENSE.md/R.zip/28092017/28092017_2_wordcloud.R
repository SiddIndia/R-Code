library(twitteR)
library(base64enc)
library(tm)
library(wordcloud)
library(RCurl)

## extract the data 

## for this we need the tokend to connect with twitter

consumer_key <- ""
consumer_secret <- ""
access_token <- ""
access_secret <- ""

### connect to twitter using a function setup_twitter_oauth()
setup_twitter_oauth(consumer_key,consumer_secret, access_token, access_secret)

twitterdata <- searchTwitter("Trump", n = 500, lang = "en")
## Check if the data is correct
twitterdata

## get only text data
length(twitterdata)

ttext <- vector()
for (iTw in 1 : length(twitterdata)) 
{
  ttext[iTw] <- twitterdata[[iTw]]$getText()
}

## Cleaning
## corpus in R 
## it collects all the lines and save it in a document format
## tm package
## most easiest way to clean data in R

tcorpus <- Corpus(vector(ttext))
tcorpus

## accessing data
tcorpus[[1]]$content

## removing white space
tclean <- tm_map(tcorpus, stripWhitespace)

## remove punctuations
tclean <- tm_map(tclean, removePunctuation)

## remove numbers
tclean <- tm_map(tclean, removeNumbers)

## change everything to lowercase 
tclean <- tm_map(tclean, content_transformer(tolower))

stopwords("en")

##remove stop words
tclean <- tm_map(tclean, removeWords, stopwords("en"))


## plot a word cloud
wordcloud(tclean, random.order = F, col = raindow(50), max.words = 75)
