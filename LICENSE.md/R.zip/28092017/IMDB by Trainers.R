#### IMDB

IMDBData3 <- read.csv(file.choose())
View(IMDBData3)


IMDBData5 <- subset(IMDBData3, IMDBData3$country == "USA")
View(IMDBData5)

## fix to get same values
## set.seed(pass some number)
set.seed(1234)

nrow(IMDBData5)
which(is.na(IMDBData5))


IMDBData5 <- na.omit(IMDBData5)
which(is.na(IMDBData5))
indexIMDB <- sample(nrow(IMDBData5), 0.7 * nrow(IMDBData5), replace = F)

traindataIMDB <- IMDBData5[indexIMDB,]
nrow(traindataIMDB)
testdataIMDB <- IMDBData5[-indexIMDB,]
nrow(testdataIMDB)

names(testdataIMDB)


### 
MIMDBModel <- lm(gross~director_facebook_likes+num_voted_users+budget, data = traindataIMDB)
summary(MIMDBModel)
str(testdataIMDB)

library(car)
vif(MIMDBModel)

Predimdbscore1 <- predict(MIMDBModel,testdataIMDB)

ErrFunctionIMDB <- function(actualYIMDB, predictedYIMDB) {
  errorIMDB = actualYIMDB - predictedYIMDB
  sqerrorIMDB = errorIMDB^2
  meansqerrorIMDB = mean(sqerrorIMDB)
  sqrt(meansqerrorIMDB)
}

ErrFunctionIMDB(testdataIMDB$gross, Predimdbscore1)
