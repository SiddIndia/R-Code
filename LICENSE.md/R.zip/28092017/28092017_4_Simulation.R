#### Simulation ####


## simulate means generate an underlying distribution

## mean of 25 min and sd of 5 mins

## mean of 27 min and sd of 3 mins

## rnorm() is the function to simulate
## normal distribution

## simulate 100 datapoints with mean as 24 and sd as 3

set.seed(1234)
## rnorm(number of simulation, mean, sd)
var1 <- rnorm(10000, 24, 3)
hist(var1)
mean(var1)
sd(var1)


## mean of 25 min and sd of 5 mins
p1 <- rnorm(10000, 25, 5)
hist(p1)
mean(p1)
sd(p1)

## probablilty of success of this p1 wrt to target of 30 mins
length(subset(p1, p1<30))/length(p1)


## mean of 27 min and sd of 3 mins
p2 <- rnorm(10000, 28, 3)
hist(p2)
mean(p2)
sd(p2)

## probablilty of success of this p1 wrt to target of 30 mins
length(subset(p2, p2<30))/length(p2)


## pizza 1 - 4000 deliveries
Revenuep1 <- 4000*0.84*150 -  4000*(1-0.84)*200

## pizza 2 - 4500 deliveries
Revenuep2 <- 4500*0.74*150 -  4500*(1-0.74)*200

### we will give the range of wieght 
### give us back the range of prediction

## data("mtcars")


## create the mode
## mpg explined by wt
lm1<- lm(data = mtcars, mpg~wt)
summary(lm1)

wt1 <-rnorm(1000, mean(mtcars$wt), sd(mtcars$wt))
wt1

lm1$coefficients[1]
mpg1 = lm1$coefficients[1] + lm1$coefficients[2] * wt1

hist(mpg1)
summary(mpg1)


#### Model with 2 variables
names(mtcars)
lm2<- lm(data = mtcars, mpg~wt+hp)
summary(lm2)

wt3 <-rnorm(1000, mean(mtcars$wt), sd(mtcars$wt))
hp3 <-rnorm(1000, mean(mtcars$hp), sd(mtcars$hp))

wt1

lm2$coefficients[1]
mpg2 = lm2$coefficients[1] + lm2$coefficients[2] * wt3 + lm2$coefficients[3] * hp3

hist(mpg2)
summary(mpg2)


#### Profit basis conversion
#### Profit = L*R*PC
#### L : Mean = 40 , sd = 3
#### R : Mean = 0.7, sd = 0.03
#### PC : Mean = 750000, sd = 21000


L1 <-rnorm(10000, 40, 3)
R1 <-rnorm(10000, 0.7, 0.03)
PC1 <-rnorm(10000, 750000, 21000)

Profit1 <- L1 * R1 * PC1

hist(Profit1)
summary(Profit1)

