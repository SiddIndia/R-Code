##### Market Basket Analysis

library(arules)
library(arulesViz)

data("Groceries")
## Check Class as association rules

class(Groceries)

## Viewing data
inspect(Groceries[1])
inspect(head(Groceries,10))

itemFrequencyPlot(Groceries, topN = 20)

Asscnrules <- apriori(Groceries, parameter = list(support = 0.001, confidence = 0.5))
inspect(head(Asscnrules))


inspect(head(sort(Asscnrules, by="lift")))
inspect(head(sort(Asscnrules, by="lift"),25))


#################################################
### Supermarket data
#################################################

supermarketdata <- read.transactions(file.choose(), format = "basket", sep = ",")
class(supermarketdata)
inspect(head(supermarketdata,10))
itemFrequencyPlot(supermarketdata, topN = 20)


AsscnrulesSM <- apriori(supermarketdata, parameter = list(support = 0.003, confidence = 0.3))
inspect(head(AsscnrulesSM))


inspect(head(sort(AsscnrulesSM, by="lift")))
inspect(head(sort(AsscnrulesSM, by="lift"),25))
