#### 1. ARIMA

### Sidd

library(forecast)
library(tseries)

?AirPassengers
class(AirPassengers)
### Time sries data should be in ts class format

plot(AirPassengers)

decompdAP <- stl(AirPassengers, s.window = "periodic") 
plot(decompdAP)

library(nortest)
### ADF test
adf.test(AirPassengers, alternative = "stationary")
## Model 1 
APmodel <- arima(AirPassengers, order = c(0,0,1), seasonal = c(0,1,0))

pacf(APmodel$residuals)
acf(APmodel$residuals)

## Model 2 
APmodel2 <- arima(AirPassengers, order = c(0,1,1), seasonal = c(0,2,0))

pacf(APmodel2$residuals)
acf(APmodel2$residuals)

##Model 2 seems to have less variation in the PACF and ACF and hence is a better model and has better AIC

##################################################################3

# Question 2.
library(forecast)

NottemModel <- auto.arima(nottem)
pacf(NottemModel$residuals)
acf(NottemModel$residuals)

NottemForecast <- forecast(NottemModel,70, level = 95)
plot(NottemForecast)
NottemForecast


#### Value for July1945 is 48.99472


######################################################################

#Question 5.
#### Random Forest for Wine data

WRFdata <- read.csv(file.choose())
View(WRFdata)
str(WRFdata)

WRFdata$Wine <- as.factor(WRFdata$Wine)
str(WRFdata)

library(randomForest)

rfWine <- randomForest(Wine~., data = WRFdata, ntree = 20)
### plot of importance of variable
varImpPlot(rfWine, sort = T)



#### split the test and train data
set.seed(1453)

inWine <- sample(nrow(WRFdata), 0.65 * nrow(WRFdata), replace = F)

trdataWine <- WRFdata[inWine,]
nrow(trdataWine)
ttdataWine <- WRFdata[-inWine,]
nrow(ttdataWine)
names(ttdataWine)
nrow(trdataWine)+ nrow(ttdataWine)


rfwine1 <- randomForest(Wine~Proline+OD+Flavanoids+Color.int+Alcohol+Hue , data = trdataWine, ntree = 20)
varImpPlot(rfwine1, sort = T)

rfwine1

## use predict function
ttpredictWine <- predict(rfwine1,ttdataWine,type = "class")
ttpredictWine

confWine2 <- table(ttpredictWine,ttdataWine$Wine)

## accuracy of the model
sum(diag(confWine2))/sum(confWine2)

### Accuracry is 0.9365079 for the Random forest wih variables Proline+OD+Flavanoids+Color.int+Alcohol+Hue



##############################################

# Question 7
dmtcar <- mtcars

library(ggplot2)
## qplot(data, x, y)
qplot(data = dmtcar, x= hp, y = mpg, color = TRUE)

cor.test(data = dmtcar, dmtcar$hp, dmtcar$mpg)
## high negative correlation

l1 <- lm(data = dmtcar, dmtcar$mpg ~ dmtcar$hp)
summary(l1)

dnewCar <- data.frame(hp = 112)

l2 <- lm(data = dmtcar, mpg ~ hp)
predict(l2, dnewCar)

### The mpg for hp 112 is 22.45

## Model has a adj R value of 0.58 which is not very high...



