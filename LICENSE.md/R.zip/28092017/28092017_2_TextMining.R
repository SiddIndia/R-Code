#### Sentiment Analysis


#### apply()
m1 <- matrix(1:15, nrow =3)
m1

##apply(data structure, 1 for row / 2 column, function)

## mean of rows in m1
apply(m1, 1, mean)
apply(m1, 1, sum)

m1apply <- apply(m1, 1, sum)

str(m1apply)

### write a function istead of sum/mean which will divide the value by 2

Cfuntion <- function(sValue) {
  
  Hvalue = sValue/2
  return(Hvalue)
}

m2apply <- apply(m1, 2, Cfuntion)
m2apply


##### sapply()

l1 <- list(1:10, 21:45)

l1

sapply(l1,mean)


Sqfuntion <- function(OValue) {
  
  Sqvalue = OValue^2
  return(Sqvalue)
}

sapply(l1,Sqfuntion)



#### rowSums()
m1
rowSums(m1)

#### match()

d<- c(4,5,6,75, 3, 4,6,8)
c<- c(4,8)

match(d,c)

sum(is.na(match(d,c)))

sum(!is.na(match(d,c)))


### We will use a text file instead of csv

#### Text analytics file Laptop reviews

#### readLines() and scan()

lapreview <- readLines(file.choose())
lapreview
lapreview[1]

### Read the memory of positive words
poswords <- scan(file.choose(), what = "character", comment.char = ";")
poswords
### Read the memory of neagtive words
negwords <- scan(file.choose(), what = "character", comment.char = ";")
negwords



## we are going to clean the lapreview
## remove punctuations, extra space
## we will split the lines into words
## we will compare each word to our memory
## assign postive score to pos words (+1)
## assign negative score to neg words (-1)
## Sum a post and neg score for a line
## if the sum is positive, line is postive then review is postive

## regular expression
## it represents say number, punctuations, space,
## for punctuations the notation is [[:punct:]]
## for white space the notation is  \\s+
## for numbers the notation is  \\d+


## Cleaning data
for(i in 1: length(lapreview))
{
  #remove numbers
  lapreview[i] <- gsub("\\d+", " ", lapreview[i])
  # remove punctuations
  lapreview[i] <- gsub("[[:punct:]]", " ", lapreview[i])
}

## Splitting data
## each sentence is now a going to split into words

library(stringr)
lreviewsplit <- str_split(lapreview, "\\s+")
lreviewsplit[1]

## each word in each line will be compared
## roughly 90 or 92 lines similary we should get 90 scores
## sum of pos and neg scores based on that particular line

finalscore <- 0
for(j in 1 : length(lreviewsplit))
{
  ## match pos words
  poswordsmatched <- sapply(lreviewsplit[j], function(x){match(x, poswords)})
  sump <- sum(!is.na(poswordsmatched))
  
  ## match neg words
  negwordsmatched <- sapply(lreviewsplit[j], function(x){match(x, negwords)})
  sumn <- sum(!is.na(negwordsmatched))
  finalscore[j] <- sump - sumn
}

hist(finalscore)


#### NPS ############

### NPS = % promotes - %Detracters

dprom <- length(subset(finalscore, finalscore > 0))

ddetrac <- length(subset(finalscore, finalscore < 0))

dnuet <- length(subset(finalscore, finalscore == 0))
dprom
ddetrac
dnuet

dpromp <- dprom/sum(dprom+ddetrac+dnuet)
ddetracp <- ddetrac/sum(dprom+ddetrac+dnuet)

##dtotal = length(finalscore)

NPS <- (dpromp - ddetracp)*100

