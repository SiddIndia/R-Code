library(forecast)
library(tseries)

?co2
class(co2)
### Time sries data should be in ts class format

plot(co2)

decompd <- stl(co2, s.window = "periodic") 
plot(decompd)

### ADF test
adf.test(co2, alternative = "stationary")

comodel <- arima(co2, order = c(1,1,2), seasonal = c(2,0,0))

#diff(co2, differences = 2)


pacf(comodel$residuals)
acf(comodel$residuals)

newCOModel <- auto.arima(co2)
pacf(newCOModel$residuals)
acf(newCOModel$residuals)

library(nortest)
ad.test(newCOModel$residuals)


newCoForecast <- forecast(newCOModel,200, level = 95)
plot(newCoForecast)



####################################
### airmiles
####################################

newAMModel <- auto.arima(airmiles)
pacf(newAMModel$residuals)
acf(newAMModel$residuals)

library(nortest)
ad.test(newAMModel$residuals)


newAMForecast <- forecast(newAMModel,5, level = 95)
plot(newAMForecast)