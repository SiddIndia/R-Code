#### Random Forest for Wine data

WRFdata <- read.csv(file.choose())
View(WRFdata)
str(WRFdata)

WRFdata$Wine <- as.factor(WRFdata$Wine)
str(WRFdata)

library(randomForest)

rfWine <- randomForest(Wine~., data = WRFdata, ntree = 20)
### plot of importance of variable
varImpPlot(rfWine, sort = T)



#### split the test and train data
set.seed(1453)

inWine <- sample(nrow(WRFdata), 0.65 * nrow(WRFdata), replace = F)

trdataWine <- WRFdata[inWine,]
nrow(trdataWine)
ttdataWine <- WRFdata[-inWine,]
nrow(ttdataWine)
names(ttdataWine)
nrow(trdataWine)+ nrow(ttdataWine)


rfwine1 <- randomForest(Wine~Proline+OD+Flavanoids+Color.int+Alcohol+Hue , data = trdataWine, ntree = 20)
varImpPlot(rfwine1, sort = T)

rfwine1

## use predict function
ttpredictWine <- predict(rfwine1,ttdataWine,type = "class")
ttpredictWine

confWine2 <- table(ttpredictWine,ttdataWine$Wine)

## accuracy of the model
sum(diag(confWine2))/sum(confWine2)

