### Decision tree

### Read the Data
### the scenario is below
### 

winedata <- read.csv(file.choose())
View(winedata)
str(winedata)


winedata$Wine <- as.factor(winedata$Wine)
str(winedata)

## Split the data
## set.seed(pass some number)
set.seed(1453)

indexWine <- sample(nrow(winedata), 0.7 * nrow(winedata), replace = F)

traindataWine <- winedata[indexWine,]
nrow(traindataWine)
testdataWine <- winedata[-indexWine,]
nrow(testdataWine)
names(testdataWine)


### Building the model using rpart fuction in rpart
# call the package
library(rpart)
library(rpart.plot)

## build the model and assign that to a variable
## rpart(data, y~x1+x2+x3+x4, method = "class")
dt1 <- rpart(data = traindataWine, Wine~Alcohol+Acl+Proline, method = "class")
## plotting the D tree using rpart,plot()
rpart.plot(dt1)


### Test the model on test data
testprediction <- predict(dt1,testdataWine, type = "class")
testprediction

## creating confusion matrix
confWine <- table(testprediction,testdataWine$Wine)

## accuracy of the model
sum(diag(confWine))/sum(confWine)

### predict for a new data of wine where alcohol = 15, acl = 18, proline = 950
newWine <- data.frame(Alcohol = 15, Acl = 18, Proline = 950)

## use predict function
predict(dt1,newWine,type = "class")

## probability
predict(dt1,newWine,method = "response")



#### build another model using Phenols, Proanth, Mg

WineNewdata <- winedata
## Split the data
## set.seed(pass some number)
set.seed(1453)

indexWineNew <- sample(nrow(WineNewdata), 0.7 * nrow(WineNewdata), replace = F)

traindataWineNew <- WineNewdata[indexWineNew,]
nrow(traindataWineNew)
testdataWineNew <- WineNewdata[-indexWineNew,]
nrow(testdataWineNew)
names(testdataWineNew)


### Building the model using rpart fuction in rpart
# call the package
library(rpart)
library(rpart.plot)

## build the model and assign that to a variable
## rpart(data, y~x1+x2+x3+x4, method = "class")
dt2 <- rpart(data = traindataWineNew, Wine~Phenols+Mg+Proanth, method = "class")
## plotting the D tree using rpart,plot()
rpart.plot(dt2)


### Test the model on test data
testpredictionNew <- predict(dt2,testdataWineNew, type = "class")
testpredictionNew

## creating confusion matrix
confWineNew <- table(testpredictionNew,testdataWineNew$Wine)

## accuracy of the model
sum(diag(confWineNew))/sum(confWineNew)

### predict for a new data of WineNew where alcohol = 15, acl = 18, proline = 950
newWineNew <- data.frame(Phenols = 2.6, Mg = 117, Proanth = 1.9)

## use predict function
predict(dt2,newWineNew,type = "class")

## probability
predict(dt2,newWineNew,method = "response")



