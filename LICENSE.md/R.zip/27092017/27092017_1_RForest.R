#### Random Forest

## Take a different dataset
## data set is from bank
## Cross sellin a product for an existing customer
## There are existing cutomer for fixed deposit
## try cross selling loans to them
## data set is from UCI ML

bdata <- read.csv(file.choose())

### Sep is ';'
bdata <- read.csv(file.choose(), sep = ";")
View(bdata)


### Extract age, job, duration, balance, y

newbdata <- bdata[,c(1,2,6,12,17)]
View(newbdata)

#### split the test and train data
set.seed(1453)

inbank <- sample(nrow(newbdata), 0.65 * nrow(newbdata), replace = F)

traindatabank <- newbdata[inbank,]
nrow(traindatabank)
testdatabank <- newbdata[-inbank,]
nrow(testdatabank)
names(testdatabank)
nrow(testdatabank)+ nrow(traindatabank)

### Create the Random forest

##################################################
### Out of context
##################################################

# using bdata
#randomForest()

library(randomForest)

rfbank <- randomForest(y~., data = bdata, ntree = 20)
### plot of importance of variable
varImpPlot(rfbank, sort = T)


##################################################
### Out of context Over
##################################################

### Continue from row 34

## Run the model using Randomforest()
## randomforest(dataset, targetvariable, explained by predictir variable, number of tree)

rfbank2 <- randomForest(y~. , data = traindatabank, ntree = 20)
varImpPlot(rfbank2, sort = T)

rfbank2

## use predict function
testpredictbank <- predict(rfbank2,testdatabank,type = "class")
testpredictbank

confbank <- table(testpredictbank,testdatabank$y)

## accuracy of the model
sum(diag(confbank))/sum(confbank)