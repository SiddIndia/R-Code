### Clustering

age <- c(21, 25, 67, 81, 30, 19, 81, 61, 72, 58)
plot(age,age)
plot(age,age, pch = 15)
centroid1 <- 25
centroid2 <- 70

agedf <- data.frame(age,centroid1,centroid2)
agedf
agedf$DiffC1 <- abs(agedf$age - agedf$centroid1)
agedf$DiffC2 <- abs(agedf$age - agedf$centroid2)
agedf

agedf$Segment <- ifelse(agedf$DiffC1 > agedf$DiffC2, 2, 1)
agedf
plot(age, age, pch = 15, col = agedf$Segment)


a <- c(3,7,8,12)
b <- c(2,8,1,9)


## Euclidian
sqre = (a-b)^2
cum = sum(sqre)
dist = sqrt(cum)
dist

#manhatan
abs(a-b)
sum(abs(a-b))

c1 <- a-b

##########################

newdata<-iris
newdata$Species<-NULL
View(newdata) 


# We us the k mean model for clustering model

# the format is kmeans(data, no of centres)
# no of centers implies the number of groups or clusters

Kmeansmodel <- kmeans(newdata, centers = 3)

### plot of newdata bivariate
plot(newdata$Sepal.Length, newdata$Sepal.Width, pch =15, col = Kmeansmodel$cluster)


### plot of newdata all
pairs(newdata,col = Kmeansmodel$cluster)


confMatPetal <- table(iris$Species, Kmeansmodel$cluster)
confMatPetal


#########################################
## Checking the number of clusters######
########################################
## Checking to find the segmentation within the cluster groups in a super market

# u can either 3, 4 or 5 based on business req

dataSmarket <- read.csv(file.choose())
View(dataSmarket)
str(dataSmarket)

dataSmarket$Genre <- NULL
dataSmarket$CustomerID <- NULL
KmeansmodelSMarket <- kmeans(dataSmarket, centers = 6)
KmeansmodelSMarket
### plot of newdata bivariate
plot(dataSmarket$Age, dataSmarket$purchase.index..1.100., pch =15, col = KmeansmodelSMarket$cluster)


### plot of newdata all
pairs(dataSmarket,col = KmeansmodelSMarket$cluster)


### Elbow method

set.seed(123)
# Compute and plot wss for k = 2 to k = 15.
wss <- (nrow(dataSmarket) - 1)* sum(apply(dataSmarket,2,var))

for( i in 2:15) {
  wss[i] <- sum(kmeans(dataSmarket,i)$withinss)
}

wss

plot(1:15, wss, type = "b")

dataSmarket2 <- cbind(dataSmarket, KmeansmodelSMarket$cluster)

write.csv(dataSmarket2,"clusters_6.csv")


