#### Credit Risk Modelling ####

## Two conditions for the model
## Y>0
## Y<1

## p = e^y/(1+e^y)
## q = 1/(1+e^y)
## y = log(p/(1-p))

loandata <- readRDS(file.choose())
View(loandata)
head(loandata,15)
str(loandata)

which(is.na(loandata))

summary(loandata)

boxplot(loandata$loan_amnt)

loandataNew <- subset(loandata, loandata$ir_cat != "Missing")
loandataNew
nrow(loandataNew)
View(loandataNew)

set.seed(1234)
loanindex <- sample(nrow(loandataNew), 0.8*nrow(loandataNew))
Trainloan <- loandataNew[loanindex,]
TestLoan <- loandataNew[-loanindex,]

nrow(Trainloan)
nrow(TestLoan)


### To build binary model we use the function GLM

names(Trainloan)
loanmodel <- glm(loan_status ~ age+home_ownership, data = Trainloan, family = "binomial" )
summary(loanmodel)
Predictedloan <- predict(loanmodel,newdata = TestLoan, type = "response")
Predictedloan

## Assuming the threshold to be 12%
pridictbin <- ifelse(Predictedloan>0.12,1,0)
pridictbin

### Model Validation
confloan <-table(TestLoan$loan_status,pridictbin)
confloan
## Accuracry of the model
sum(diag(confloan))/sum(confloan)

TN <- confloan[1]
FN <- confloan[2]
FP <- confloan[3]
TP <- confloan[4]

spsty <- TN/(FP+TN)
snsty <- TP/(FN+TP)

spsty
snsty