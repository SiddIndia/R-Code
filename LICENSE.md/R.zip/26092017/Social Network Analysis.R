#### Social Network Analysis

library(igraph)
SNAdata <- read.csv(file.choose(),row.names = 1)
View(SNAdata)
SNAmatrix <- as.matrix(SNAdata)
class(SNAmatrix)
sna <- graph.adjacency(SNAmatrix,mode = "directed", diag = F)

plot(sna)

### Betweenness - person who builds the shortest path
### Degrees - number of connections

degree(sna)
betweenness(sna)


plot(sna, vertex.size = degree(sna) , vertex.color = betweenness(sna), edge.arrow.size = 1/3, layout = layout.star)

