### Reading data set

dIMDB<- read.csv(file.choose())
View(dIMDB)
head(dIMDB,15)

### Checking NA Values in the data

is.na(dIMDB)
which(is.na(dIMDB))
str(dIMDB)

### EDA

summary(dIMDB$cast_total_facebook_likes)
summary(dIMDB$budget)
summary(dIMDB$imdb_score)
summary(dIMDB$movie_facebook_likes)

### Box plot of each variables
boxplot(dIMDB$imdb_score)

ggplot(dIMDB, aes(title_year))+geom_bar()+
  labs(x="Year movie was released", y="Movie Count", title="Histogram of Movie released")

dIMDB$Profit <- dIMDB$gross - dIMDB$budget
dIMDNew <- subset(dIMDB , dIMDB$Profit >0)
na.omit(dIMDNew)

ggplot(dIMDNew, aes(x=dIMDNew$budget, y=dIMDNew$Profit))+ geom_point() + geom_smooth(method='lm')

ggplot(dIMDNew,aes(x=num_voted_users))+geom_histogram(binwidth=50000,fill="black")

ggplot(dIMDNew, aes(x=num_voted_users,y=imdb_score,col=cut(imdb_score,5)))+geom_point()+geom_jitter()+labs(title="number of users voted vs Imdb score",col="imdb score")+theme(legend.position = "bottom")

#### Facebook analysis

ggplot(dIMDNew, aes(x=movie_facebook_likes,y=imdb_score))+
  geom_point(color="purple",alpha=0.4)+theme(legend.position="bottom",plot.title = element_text(size=8))+labs(title="Movie FB likes vs Score")


ggplot(dIMDNew, aes(x=director_facebook_likes,y=imdb_score))+
  geom_point(color="hotpink",alpha=0.4)+theme(legend.position="bottom",plot.title = element_text(size=8))+labs(title="Director FB likes vs Score")

ggplot(dIMDNew, aes(x=actor_1_facebook_likes,y=imdb_score))+
  geom_point(color="red4",alpha=0.4)+theme(legend.position="bottom",plot.title = element_text(size=8))+labs(title="Actor1 FB likes vs Score")

ggplot(dIMDNew, aes(x=actor_2_facebook_likes,y=imdb_score))+
  geom_point(color="maroon",alpha=0.4)+theme(legend.position="bottom",plot.title = element_text(size=8))+labs(title="Actor2 FB likes vs Score")