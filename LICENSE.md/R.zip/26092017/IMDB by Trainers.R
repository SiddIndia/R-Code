#### IMDB

IMDBData3 <- read.csv(file.choose())
View(IMDBData3)


IMDBData5 <- subset(IMDBData3, IMDBData3$country == "USA")

## fix to get same values
## set.seed(pass some number)
set.seed(1234)

nrow(IMDBData5)
indexIMDB <- sample(nrow(IMDBData5), 0.7 * nrow(IMDBData5), replace = F)

traindataIMDB <- IMDBData5[indexIMDB,]
nrow(traindataIMDB)
testdataIMDB <- IMDBData5[-indexIMDB,]
nrow(testdataIMDB)

names(testdataIMDB)

### Car model will have 22 obs
MIMDBModel <- lm(imdb_score~duration+movie_facebook_likes+budget, traindataIMDB)
summary(MIMDBModel)

Predimdbscore1 <- predict(MIMDBModel,traindataIMDB)

ErrFunctionIMDB <- function(actualYIMDB, predictedYIMDB) {
  errorIMDB = actualYIMDB - predictedYIMDB
  sqerrorIMDB = errorIMDB^2
  meansqerrorIMDB = mean(sqerrorIMDB)
  sqrt(meansqerrorIMDB)
}

ErrFunctionIMDB(testdataIMDB$imdb_score, Predimdbscore1)
