### mtcars data set
## mpg, wt, hp
## how mpg changes against wt
## qplot()


dmtcar <- mtcars

library(ggplot2)
## qplot(data, x, y)
qplot(data = dmtcar, x= wt, y = mpg, color = TRUE)

## Find relationship between mpg and wt
## correlation study
## correlation coeff:  -1 to +1
## -1 --> perfect negative linear
## +1 --> perfect positive linear
## 0 --> no relation
## 0-0.3 - Weak positive
## 0.3 - 0.6 - moderate
## 0.6 - 1 - high

## find correlation between mpg and wt
## mistakes - Bias in data, etc.
## probability of making a mistake in correlation - p value
## p value - should have threshold < 0.05
## cor.test() - function used to test correlation
## cor.test(data, x, y)

cor.test(data = dmtcar, dmtcar$wt, dmtcar$mpg)
## high negative correlation

## we know its a negative relationship
## we can build simple Linear regression
## lm() is used to build the model
## lm(data, dependent variable ~ independent variable)

lm(data = dmtcar, dmtcar$mpg ~ dmtcar$wt)
## mpg = k + C*wt
## mpg = 37.285 - 5.344 * wt
## before we use any model, we have to validate assumption
## p value <0.05
## Adj R square - Change in Dep explained by Independent Variable
## Varies from 0 - 100%: 70% and above is considered good
## look for logicality of relationship using signs

## to get the adj R square and P value
l1 <- lm(data = dmtcar, dmtcar$mpg ~ dmtcar$wt)
summary(l1)

## Model is good and validates, Lets Predict mpg for a car of 3.2
## create a dataframe which holds the value 3.2
dnewCar <- data.frame(wt = 3.2)

## prediction is done using predict()
## predict(object where our model is stire, newdataset)
l2 <- lm(data = dmtcar, mpg ~ wt)
predict(l2, dnewCar)

## model for mpg explianed by hp and predict an hp for 105
## Correlation
cor.test(data = dmtcar, dmtcar$hp, dmtcar$mpg)
## Highly negative correlation
l3 <- lm(data = dmtcar, mpg ~ hp)
summary(l3)

# mpg = 30.09886 - 0.0682 * hp
## adj r square = 0.5892 
## p value for hp = 1.79e-07

dnewCarhp <- data.frame(hp = 105)
predict(l3,dnewCarhp)


##################################################################################
## Build a model using multiple variables
## assumptions 
### 1) p value for individual x and overall model
### 2) multicollinarity - x1, x2, x3 are independent - they dont change b/w them
##### VIF - variance inflation factor < 10 no multicolliniarity
##### adj r square
##### normaility of the residual
##### logical relationship

# y - mpg
# x1 - hp, x2 - cyl, x3 - qsec
# build the model using lm()

ml1 = lm(data = dmtcar, mpg ~ hp + cyl + qsec)
summary(ml1)
# adj r square - 0.7517
# p-value: 3.135e-09
# (Intercept) 55.30540   
# hp          -0.03552
# cyl         -2.26960
# qsec        -0.89424  

## VIF
library(car)
vif(ml1)
#hp      cyl     qsec 
#4.250429 3.257058 2.006379 

## Normality
library(nortest)
## Call function rstandard()
## used to extract the residual
resml1 <- rstandard(ml1)
resml1

### Check for normaility - Done using a test called AD test
#### Anderson Darling test
#### we will only look at p value from the test - here p value should be > 0.5
#### ad.test()

ad.test(resml1)
## p-value = 0.1192 - model is fit for prediction
dnewCarMLR <- data.frame(hp = 120, qsec = 14, cyl = 3)
predict(ml1,dnewCarMLR)

