### Training and Test data set

### Sample with replacement, without replcaement
## sample (from, umber, replace)
sample(5,8, replace = T)

## fix to get same values
## set.seed(pass some number)
set.seed(234)
sample(5,8, replace = T)

dDiamonds1 <- diamonds
nrow(dDiamonds1)
index <- sample(nrow(dDiamonds1), 0.7 * nrow(dDiamonds1), replace = F)

traindata <- dDiamonds1[index,]
nrow(traindata)
testdata <- dDiamonds1[-index,]
nrow(testdata)

#############################################
### Sample model using mtcars data

dcarsData <- mtcars
nrow(dcarsData)
indexCars <- sample(nrow(dcarsData), 0.7 * nrow(dcarsData), replace = F)

traindataCars <- dcarsData[indexCars,]
nrow(traindataCars)
testdataCars <- dcarsData[-indexCars,]
nrow(testdataCars)
dim(traindataCars)

### Car model will have 22 obs
MCarModel <- lm(mpg~wt+qsec+drat+hp, traindataCars)
Predmpg1 <- predict(MCarModel,testdataCars)

ErrFunction <- function(actualY, predictedY) {
  error = actualY - predictedY
  sqerror = error^2
  meansqerror = mean(sqerror)
  sqrt(meansqerror)
}

ErrFunction(10, 12)

ErrFunction(testdataCars$mpg, Predmpg1)

### Model 2
View(traindataCars)
?mtcars
MCarModel2 <- lm(mpg~wt+qsec+drat+gear, traindataCars)
Predmpg12 <- predict(MCarModel2,testdataCars)
ErrFunction(testdataCars$mpg, Predmpg12)
