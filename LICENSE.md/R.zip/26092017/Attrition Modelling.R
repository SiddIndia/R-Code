### Attrition Modelling
hrdata <- read.csv(file.choose())
View(hrdata)
head(hrdata,15)
str(hrdata)

which(is.na(hrdata))
summary(hrdata)

boxplot(hrdata$MonthlyIncome)

set.seed(1234)
hrindex <- sample(nrow(hrdata), 0.8*nrow(hrdata))
Trainhr <- hrdata[hrindex,]
Testhr <- hrdata[-hrindex,]

##########################################

nrow(Trainhr)
nrow(Testhr)

names(Trainhr)
### To build binary model we use the function GLM

hrmodel <- glm(Attrition ~ JobSatisfaction+DistanceFromHome+YearsWithCurrManager+MonthlyIncome, data = Trainhr, family = "binomial" )
summary(hrmodel)
Predictedhr <- predict(hrmodel,newdata = Testhr, type = "response")
Predictedhr

## Assuming the threshold to be 20%
pridictbinhr <- ifelse(Predictedhr>0.20,1,0)
pridictbinhr

### Model Validation
confhr <-table(Testhr$Attrition,pridictbinhr)
confhr
## Accuracry of the model
sum(diag(confhr))/sum(confhr)

TNhr <- confhr[1]
FNhr <- confhr[2]
FPhr <- confhr[3]
TPhr <- confhr[4]

spstyhr <- TNhr/(FPhr+TNhr)
snstyhr <- TPhr/(FNhr+TPhr)

spstyhr
snstyhr